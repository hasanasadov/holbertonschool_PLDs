import React from 'react';

function TodoItem({ task, index, completeTask, deleteTask }) {
  return (
    <div className={`todo-item ${task.completed ? 'completed' : ''}`}>
      <span>{task.text}</span>
      <button onClick={() => completeTask(index)}>{task.completed ? 'Undo' : 'Complete'}</button>
      <button onClick={() => deleteTask(index)}>Delete</button>
    </div>
  );
}

export default TodoItem;
